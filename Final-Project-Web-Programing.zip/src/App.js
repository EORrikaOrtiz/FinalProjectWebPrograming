//import logo from './logo.svg';
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './components/Login';
import AdminDashboard from './components/Administrator';
import UserDashboard from './components/User';

const App = () => {
  return (
    <Router>
    <Routes>
    <Route path="/" element={<Login />} />
    <Route path="/AdminDashboard" element={<AdminDashboard />} />
    <Route path="/UserDashboard" element={<UserDashboard/>}/>
    </Routes>
  </Router>
  );
}

export default App;
