import React, { useState } from 'react';
import {useNavigate} from "react-router-dom";
import axios from "axios";
import '../Login.css';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();  
    setError(''); 
    
    try {
      const response = await axios.post('http://localhost:7000/login', 
      {username, password},
      {headers: {'Content-Type': 'application/json'}}
      );
      const { message } = response.data; 
    if (response.status === 200 ) {
      navigate('/AdminDashboard');
    } else {
      setError(message ||'Unexpected response status received.'); 
    }
  } catch (err) {
    console.error('Login error:', err);
    
    if (err.response && err.response.status === 401) {
      setError('Invalid username or password'); 
    } else {
      setError('An error occurred. Please try again.'); 
    }
  }
};

  return (
    <div className="login-background"> 
    <form onSubmit={handleLogin} className='login-form'>
      <h2>Login</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        required               
      />
      <br/> 
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required       
      />
      
      <button type="submit" className='submit-button'>Login</button>
      <div className="secondary-button-container">
        <button type="button" onClick={() => navigate('/UserDashboard')} className='secondary-button'>Click for Any User</button>
      </div>
    </form>
    </div>
  
  );
};


export default Login;

