import React, { useEffect, useState } from 'react';
import '../User.css';


const UserDashboard = ({ data }) => {
  const [books, setBooks] = useState([]);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchBooks = async () => {
      try {
        const response = await fetch('http://localhost:7000/books', {
          headers: { Authorization: `Bearer ${data}` },
        });

        if (response.ok) {
          const data = await response.json();
          setBooks(data);
        } else {
          setError('Failed to fetch books');
        }
      } catch (err) {
        setError('An error occurred while fetching books');
      }
    };

    fetchBooks();
  }, [data]);

  const filteredBooks = books.filter(
    (book) =>
      book.id.toString().includes(searchTerm) ||
      book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.publicationDate.includes(searchTerm)
  );

  return (
    <div className='user-dashboard'>
      <div className='user-header'>  
      <h2>User Dashboard Book Management</h2>
      <button onClick={() => window.location.href = '/'}>Log Out</button>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      </div>
    
      <input
        className='search-bar'
        type="text"
        placeholder="Search by ID, Title, Author, or Publication Date"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />
      <button onClick={() => setSearchTerm('')}>Clear Search</button>

      <ul className='book-list'>
        {filteredBooks.map((book) => (
          <li key={book.id}>
            <h3>{book.title}</h3>
            <p><strong>Author:</strong> {book.author}</p>
            <p><strong>Description:</strong> {book.description}</p>
            <p><strong>Publication Date:</strong> {book.publicationDate}</p>
            <img src={book.coverImage} alt={book.title} style={{ maxWidth: '100px' }} />
          </li>
        ))}
      </ul>
    </div>
  );
};

export default UserDashboard;
