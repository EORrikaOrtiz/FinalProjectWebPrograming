import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../Administrator.css';

const AdminDashboard = (data) => {

const [bookData, setBookData] = useState({
    title: '',
    author: '',
    description: '',
    publicationDate: '',
    coverImage: '',
  });
  const [updateData, setUpdateData] = useState({
    id: '',
    title: '',
    author: '',
    description: '',
    publicationDate: '',
    coverImage: '',
  })
  //const [bookId, setBookId] = useState('');
  const [retrievedBookId, setRetrieveBookId] = useState ('');
  const [deleteBookId, setDeleteBookId] = useState('');
  const [error, setError] = useState(null);
  const [actionMessage, setActionMessage] = useState(''); 
  const [updateMessage, setUpdateMessage] = useState('');
  const [retrieveMessage, setRetrieveMessage] = useState('');
  const [deleteMessage, setDeleteMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [books, setBooks] = useState([]);
  const [showFormAdd, setShowFormAdd] = useState(false);
  const [showFormUpdate, setShowFormUpdate] = useState (false);
  const [showFormDelete, setShowFormDelete] = useState (false);
  const [showList, setShowList] = useState (false);



  const handleChange = (e) => {
    const { name, value } = e.target;
    setBookData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const updateChange = (e) => {
    const { name, value } = e.target;
    setUpdateData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  useEffect(() => {
    const fetchBooks = async () => {
      try {
        const response = await fetch('http://localhost:7000/books', {
          headers: { Authorization: `Bearer ${data}` },
        });

        if (response.ok) {
          const data = await response.json();
          setBooks(data);
        } else {
          setError('Failed to fetch books');
        }
      } catch (err) {
        setError('An error occurred while fetching books');
      }
    };

    fetchBooks();
  }, [data]);

  const filteredBooks = books.filter(
    (book) =>
      book.id.toString().includes(searchTerm) ||
      book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.publicationDate.includes(searchTerm)
  );

  // Handle submit for adding book
  const handleAddSubmit = async (e) => {
    e.preventDefault(); 

    setActionMessage('');
    setError(null);
    setShowFormAdd(false);
    
    if (Object.values(bookData).some((field) => !field.trim())) {
      setError('All fields are required.');
      return;
    } 

    try {
      setError(null); 
      const response = await axios.post('http://localhost:7000/books', bookData, {
        headers: {'Content-Type': 'application/json'},
      });

      if (response.status === 201){
        const books = JSON.parse(localStorage.getItem('books')) || [];
        books.push(bookData);
        localStorage.setItem('books', JSON.stringify(books));

      setActionMessage(`Book "${bookData.title}" added successfully!`);
      setBookData({
        title: '',
        author: '',
        description: '',
        publicationDate: '',
        coverImage: '',
      });      
    }
  } catch (err) {
    if (err.response && err.response.status === 401) {
      setError('Unauthorized user.');
    } else {
      setError('An error occurred. Please try again later.');
    }
    console.error(err);
      } 
    }; 

    const handleRetrieveBook = async (e) => {
      e.preventDefault();

      setRetrieveMessage('');

      try {
        const response = await axios.get(`http://localhost:7000/books/${retrievedBookId.trim()}`,{
          headers: {'Content-Type': 'application/json'},
        });
        if (response.status === 200) {
          const retrievedBook = response.data;
          setUpdateData({
            id: retrievedBookId.trim(),
            title: retrievedBook.title,
            author: retrievedBook.author,
            description: retrievedBook.description,
            publicationDate: retrievedBook.publicationDate,
            coverImage: retrievedBook.coverImage,
          });
          setRetrieveMessage(`Book "${retrievedBook.title}" retrieved successfully!`);
          setError(null);          
        }
      } catch (err) {
        if (err.response && err.response.status === 404) {
          setError('Book not found.');
        } else {
          setError('An error occurred while retrieving the book.');
        }
        console.error(err);
      }
    };  
  
  
  // Handle update book
  const handleUpdateSubmit = async (e) => {
      e.preventDefault();

      setShowFormUpdate(false)
      setUpdateMessage('');    
      if (Object.values(updateData).some((field) => !field.trim())) {
        setError('All fields are required.');
        return;
      } 
    try {
      const response = await axios.put(`http://localhost:7000/books/${retrievedBookId}`, updateData , {
        headers: {'Content-Type': 'application/json'},
        });    

      if (response.status === 200) {
        const updatedBook = response.data;
        const books = JSON.parse(localStorage.getItem('books')) || [];
        const index = books.findIndex((book) => book.id === updatedBook.id)
        localStorage.setItem('books', JSON.stringify(books));
        if (index !== -1) {
          books[index] = updatedBook;  
          localStorage.setItem('books', JSON.stringify(books));       
      }

      setUpdateMessage(`Book "${updateData.title}" updated successfully!`);
      setError(null);     
    } 
  } catch (err) {
      
    if (err.response && err.response.status ===404){
          setError('Book not found.');
        } else if (err.response && err.response.status === 401) {
          setError('Unauthorized user.');
        }      
      } 
    };   
    
// Handle delete book
const handleDelete = async (e) => {
  e.preventDefault();

  setDeleteMessage('');
  setShowFormDelete(false);

  if (!deleteBookId) {
    setError("Please provide a valid Book ID.");
    return;
  }

  try {
    const response = await axios.delete(`http://localhost:7000/books/${deleteBookId}`, {
      headers: {'Content-Type': 'application/json'},
    });

    if (response.status === 204){      
      setDeleteMessage(`Book Id:"${deleteBookId}" deleted successfully!`);
      const books = JSON.parse(localStorage.getItem('books')) || [];
      const updatedBooks = books.filter(book => book.id !== deleteBookId); 
      localStorage.setItem('books', JSON.stringify(updatedBooks));
    }   
    setError(null);
        
   } catch (err) {
    if (err.response) {
      if (err.response.status === 404) {
        setError('Book not found.');
      } else if (err.response.status === 401) {
        setError('Unauthorized user.');
      } else {
        setError(`Unexpected error occurred: ${err.response.status} ${err.response.statusText}`);
      }
    } else if (err.request) {
      setError('No response from the server. Please check your connection.');
    } else {
      setError('An error occurred. Please try again later.');
    }
    setDeleteBookId('');
    } 
  };   
  return (
    <div className='AdminDashboard'>
      <div className='Admin-header'>
      <h1>Administrator Dashboard Book Management</h1>
      <button className='logOut-button' onClick={() => window.location.href = '/'}>Log Out</button>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      </div>
      <div className='search-container'>
          <input   
          className='search-bar'       
          type="text"
          placeholder="Search by ID, Title, Author, or Publication Date"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}          
          />
        <button className='clear-button' onClick={() => setSearchTerm('')}>Clear Search</button>
      </div>

      <div>       
        <button onClick={() => setShowFormAdd((prev) => !prev)}>
            {showFormAdd ? 'Back' : 'Add Book'}
        </button>
        <button onClick={() => setShowFormUpdate((prev) => !prev)}>
            {showFormUpdate ? 'Back' : 'Update Book'}
        </button>
        <button onClick={() => setShowFormDelete((prev) => !prev)}>
            {showFormDelete ? 'Back' : 'Delete Book'}
        </button>
        <button
            className="hide-list-btn"
            onClick={() => setShowList((prev) => !prev)}
        >
            {showList ? 'Hide List' : 'Show List'}
        </button>      
      </div>             
     <div className='book-add'>
      {showFormAdd && (
     <div>      
      <form onSubmit={handleAddSubmit}>
      <h2>Add a New Book</h2>
        <label>
          Title:
          <input
            type="text"
            name="title"
            value={bookData.title}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Author:
          <input
            type="text"
            name="author"
            value={bookData.author}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Description:
          <input
            type="text"
            name="description"
            value={bookData.description}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Publication Date:
          <input
            type="date"
            name="publicationDate"
            value={bookData.publicationDate}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Cover Image URL:
          <input
            type="text"
            name="coverImage"
            value={bookData.coverImage}
            onChange={handleChange}
            required
          />
        </label>
        <button type="submit">Add Book</button>   
        {actionMessage && (
        <p style={{ color: 'white', fontWeight: 'bold' }}>{actionMessage}</p>
      )}
      {error && (
        <p style={{ color: 'red', fontWeight: 'bold' }}>{error}</p>
      )}     
      </form>           
      </div>
     )}
  </div>     
  <div className='book-update'>     
      {showFormUpdate && (
    <div>      
      <form onSubmit={handleRetrieveBook}>  
      <h2>Update Book</h2>    
        <label>  Retrieve Book ID: </label>    
          <input
            type="number"
            value= {retrievedBookId}
            onChange={(e) => setRetrieveBookId(e.target.value)}   
            required        
          />
      <button type='submit' >Retrieve Book</button>   
      {retrieveMessage && (
        <p style={{ color: 'white', fontWeight: 'bold' }}>{retrieveMessage}</p>
      )}
      {error && (
        <p style={{ color: 'red', fontWeight: 'bold' }}>{error}</p>
      )}
      </form>
      {/* <h3>To update please fill this spaces:</h3> */}
      <form onSubmit={handleUpdateSubmit}>       
      <h3>To update please fill this spaces:</h3> 
      <label>
          Title:
          <input
            type="text"
            name="title"
            value={updateData.title}
            onChange={updateChange}
            required
          />
      </label>
      <label>
          Author:
          <input
            type="text"
            name="author"
            value={updateData.author}
            onChange={updateChange}            
            required
          />
      </label>  
      <label>
        Description:
          <textarea
            name="description"
            value={updateData.description}
            onChange={updateChange}
            required
          />
      </label>
      <label> 
        Publication Date:          
          <input
            type="date"
            name="publicationDate"
            value={updateData.publicationDate}
            onChange={updateChange}
            required
          />
      </label>    
      <label>
        Cover Image URL:
          <input
            type="text"
            name="coverImage"
            value={updateData.coverImage}
            onChange={updateChange}
            placeholder="Cover Image URL"
            required
          />
      </label>
          <button type="submit">Update Book</button>   
          {updateMessage && (
        <p style={{ color: 'white', fontWeight: 'bold' }}>{updateMessage}</p>
        )}
        {error && (
          <p style={{ color: 'red', fontWeight: 'bold' }}>{error}</p>
        )}          
        </form>
       
        </div>
      )}
      </div>
      <div className='book-delete'>          
      {showFormDelete && (
      <div>      
      <h2>Delete Book</h2>
      <form onSubmit={handleDelete}>
      <label>
        Book ID:      
      <input
        type="text"
        value={deleteBookId}
        onChange={(e) => setDeleteBookId(e.target.value)}
      />
      </label>
      <button type="submit">Delete Book</button>
      {deleteMessage && (
        <p style={{ color: 'white', fontWeight: 'bold' }}>{deleteMessage}</p>
        )}
        {error && (
          <p style={{ color: 'red', fontWeight: 'bold' }}>{error}</p>
        )}
      </form>
      
       </div>           
      )}
      </div>     
      {showList && (
      <ul className='book-list'>
        {filteredBooks.map((book) => (          
          <li key={book.id}>
            <h3>{book.title}</h3>
            <p><strong>Author:</strong> {book.author}</p>
            <p><strong>Description:</strong> {book.description}</p>
            <p><strong>Publication Date:</strong> {book.publicationDate}</p>
            <img src={book.coverImage} alt={book.title} style={{ maxWidth: '100px' }} />
          </li>
        ))}
      </ul>   
      )}

      </div>
  );
}

export default AdminDashboard;
